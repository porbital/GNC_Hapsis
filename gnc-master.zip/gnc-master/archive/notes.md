# Notes and References for Polaris Design

### Electrical Systems

- **IMU:** [BNO055](https://learn.adafruit.com/adafruit-bno055-absolute-orientation-sensor/overview)

- Helpful Links:
    - [Calibration Steps](https://learn.adafruit.com/adafruit-bno055-absolute-orientation-sensor/device-calibration)
    - [WebGL Example](https://learn.adafruit.com/adafruit-bno055-absolute-orientation-sensor/webgl-example)
