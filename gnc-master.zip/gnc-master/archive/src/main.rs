fn main() {
    println!("Hello, world!");

    let mut input = 0.0; // Sensor input
    let mut setpoint = 0.0;
    let mut prev_error = 0.0;
    let mut integral = 0.0;
    let mut error = 0.0; 

    loop {
        error = setpoint - input; 
        integral = integral
    }
}
