cd ~/gnc/test_data

git add *.csv

git commit -m "automatic test file update"

git push

echo "Files synced to GitHub... Also, the self-deprecating jokes finally caught up to you after slowly eroding your mental wellbeing for the past decade. GGs" 
