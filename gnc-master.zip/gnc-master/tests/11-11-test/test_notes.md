## Test Notes

Test 1: Normal. Spun up **Polaris** and turned on PID.

Test 2: Normal. Spun up **Polaris** and turned on PID.

Test 3: Both ways. Turned on PID and then spun **Polaris**.
